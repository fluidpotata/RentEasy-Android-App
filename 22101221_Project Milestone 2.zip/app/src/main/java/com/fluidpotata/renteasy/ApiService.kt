package com.fluidpotata.renteasy

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST


data class SignupRequest(
    val name: String,
    val username: String,
    val phone: String,
    val password: String,
    val confirm_password: String,
    val room_type: String
)

data class SignupResponse(val message: String)

data class LoginRequest(val username: String, val password: String)
data class LoginResponse(val access_token: String, val message: String, val role: String)

// Admin dashboard response
data class AdminDashboardResponse(
    // tickets come back as an array of arrays: [id, userId, category, subject, status, username]
    val tickets: List<List<Any>>,
    // API returns count as a nested array e.g. [[5]]; keep raw then derive if needed
    val count: List<List<Int>>,
    val joinreqs: Int,
    val rent: Int,
    val internet: Int,
    val utility: Int
) {
    // Convenience accessor if you need a simple integer
    val totalTickets: Int get() = count.firstOrNull()?.firstOrNull() ?: tickets.size
}

// Customer dashboard response
data class CustomerDashboardResponse(
    val username: String,
    val `package`: String,
    val bill: Boolean,
    val internetbill: Boolean,
    val utilitybill: Boolean,
    val ticketCount: Int
) {
    val rentUnpaid get() = bill != false
    val internetUnpaid get() = internetbill != false
    val utilityUnpaid get() = utilitybill != false
}

data class SeeAppsResponse(
    val requests: List<Map<String, Any>>,
    val available_rooms: List<Map<String, Any>>
)


interface ApiService {
    @POST("signup")
    @Headers("Content-Type: application/json")
    suspend fun signup(@Body request: SignupRequest): SignupResponse

    @POST("login")
    @Headers("Content-Type: application/json")
    suspend fun login(@Body request: LoginRequest): LoginResponse

    @GET("admin")
    suspend fun getAdminDashboard(
        @Header("Authorization") token: String
    ): AdminDashboardResponse

    @GET("customer")
    suspend fun getCustomerDashboard(
        @Header("Authorization") token: String
    ): CustomerDashboardResponse

    @GET("seeapps")
    suspend fun getSeeApps(@Header("Authorization") token: String): SeeAppsResponse

}


